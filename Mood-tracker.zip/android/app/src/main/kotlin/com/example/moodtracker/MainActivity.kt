package com.example.moodtracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
